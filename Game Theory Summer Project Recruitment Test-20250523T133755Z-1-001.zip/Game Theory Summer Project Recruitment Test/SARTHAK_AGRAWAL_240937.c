#include <stdio.h>

int main() {
    int t;
    scanf("%d", &t);

    while (t--) {
        int n;
        scanf("%d", &n);
        int arr[n];

        for (int i = 0; i < n; i++)
            scanf("%d", &arr[i]);

        int fixedAsc = 0, fixedDesc = 0;
        for (int i = 0; i < n; i++) {
            if (arr[i] == i + 1)
                fixedAsc++;
            if (arr[i] == n - i)
                fixedDesc++;
        }

        int unlockAsc = n - fixedAsc;
        int unlockDesc = n - fixedDesc;

        if (unlockAsc < unlockDesc)
            printf("Win\n");
        else if (unlockAsc > unlockDesc)
            printf("Lose\n");
        else
            printf("Tie\n");
    }

    return 0;
}
